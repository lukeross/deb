.. -*- coding: utf-8 -*-

:mod:`usbtools` - USB tools
---------------------------

.. module :: pyftdi.usbtools


Classes
~~~~~~~

.. autoclass :: UsbTools
 :members:


Exceptions
~~~~~~~~~~

.. autoexception :: UsbToolsError
