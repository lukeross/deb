from ippserver.behaviour import SaveAndRunPrinter
from subprocess import run


class SelphyJPEG(SaveAndRunPrinter):
    def __init__(self, hostname):
        super().__init__(
            "/var/tmp", False, "pdf",
            ["/usr/bin/selphy", "-printer_ip", hostname])

    def run_after_saving(self, filename, ipp_request):
        if open(filename, "rb").read(2) == b'\xff\xd8':  # Check if JPEG?
            # Selphy barfs on progressive JPEGs, so baseline them here
            formatter_args = ["/usr/bin/jpegtran", "-copy", "all", "-outfile",
                              f"{filename}.jpg", filename]
        else:
            # Probably a PDF
            formatter_args = ["/usr/bin/gs", "-q", "-dJPEGQ=98", "-dSAFER",
                              "-r300x300", "-g1800x1200", "-dPDFFitPage",
                              "-sDEVICE=jpeg", "-o", f"{filename}.jpg",
                              filename]

        if run(formatter_args).returncode:
            raise RuntimeError(f"{formatter_args[0]} failed!")
        filename += ".jpg"

        # print(repr(self.command + [filename]))
        super().run_after_saving(filename, ipp_request)
